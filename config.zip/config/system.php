<?php


return [
    'admin' => [
        'prefix' => '/admin',
        'name'=>'admin.'
    ],
    'vendor'=>[
        'prefix' => '/vendor',
        'name'=>'vendor.'
    ]
];
