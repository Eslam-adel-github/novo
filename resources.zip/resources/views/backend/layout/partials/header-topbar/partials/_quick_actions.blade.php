<div class="kt-header__topbar-item dropdown">
    <div class="kt-header__topbar-wrapper" data-toggle="dropdown" data-offset="10px,0px">
        <span class="kt-header__topbar-icon"><i class="flaticon2-gear"></i></span>
    </div>
    <div class="dropdown-menu dropdown-menu-fit dropdown-menu-right dropdown-menu-anim dropdown-menu-xl">
        <form>

            <!--begin: Head -->
            <div class="kt-head kt-head--skin-light">
                <h3 class="kt-head__title">
                  {{ __('main.quick_actions') }}
                </h3>
            </div>

            <!--end: Head -->

            <!--begin: Grid Nav -->
            <div class="kt-grid-nav kt-grid-nav--skin-light">

            </div>

            <!--end: Grid Nav -->
        </form>
    </div>
</div>
