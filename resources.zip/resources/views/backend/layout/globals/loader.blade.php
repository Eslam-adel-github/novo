<!-- begin::Page loader -->
<div class="kt-page-loader kt-page-loader--logo">
    <img style="width : 200px" alt="Logo" src="{{ asset('images/byotat-dark.svg') }}"/>
    <div class="kt-spinner kt-spinner--danger"></div>
</div>
<!-- end::Page Loader -->
