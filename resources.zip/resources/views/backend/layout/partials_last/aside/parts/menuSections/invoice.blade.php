<li class="kt-menu__item {{ is_active(config('system.vendor.name').'invoice') }}" aria-haspopup="true">
    <a href="{{ route(config('system.vendor.name').'invoice') }}" class="kt-menu__link ">
        <i class="kt-menu__link-icon flaticon2-gear"></i>
        <span class="kt-menu__link-text">Invoice</span>
    </a>
</li>
