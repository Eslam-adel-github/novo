

/*
import VeeValidate, { Validator } from "vee-validate";

import ar from "vee-validate/dist/locale/ar";

Vue.use(VeeValidate);

if (document.querySelector("html").lang == "ar") {
    // Localize takes the locale object as the second argument (optional) and merges it.
    Validator.localize("ar", ar);
}


import VueGlobalVar from "vue-global-var";

Vue.use(VueGlobalVar, {
    globals: {
        $languages: ['ar', 'en'],
    },
});

import * as VueGoogleMaps from "vue2-google-maps";
Vue.use(VueGoogleMaps, {
    load: {
      key: process.env.MIX_GOOGLE_MAP_ID,
      libraries: "places"
    }
});

 */
