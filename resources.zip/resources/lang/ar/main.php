<?php
return[
    "login"=>"Login",
    'login_success'=>"Login Successfully",
    'users'=>"Users",
    'quick_actions'                 => 'إجراءات سريعة',
    'search_in_sys_fun'             =>"بحث في خصائص السيستم"
];
