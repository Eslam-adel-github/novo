<button class="kt-aside-close " id="kt_aside_close_btn"><i class="la la-close"></i></button>
<div class="kt-aside  kt-aside--fixed  kt-grid__item kt-grid kt-grid--desktop kt-grid--hor-desktop" id="kt_aside">

    <!-- begin:: Aside Menu -->
    <div class="kt-aside-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_aside_menu_wrapper">
        <div id="kt_aside_menu" class="kt-aside-menu " data-ktmenu-vertical="1" data-ktmenu-scroll="1">
            <ul class="kt-menu__nav ">

                    <li class="kt-menu__section ">
                        <h4 class="kt-menu__section-text">
                            <?php echo e(__("main.settings")); ?>

                        </h4>
                        <i class="kt-menu__section-icon flaticon-more-v2"></i>
                    </li><!-- Group 1 -->
                    <li class="kt-menu__item" aria-haspopup="true">
                        <a href="#" class="kt-menu__link">
                            <i class="kt-menu__link-icon fa fa-database"></i>
                            <span class="kt-menu__link-text"><?php echo e(__('main.website_settings')); ?></span>
                        </a>
                    </li>


            </ul>
        </div>
    </div>
    <!-- end:: Aside Menu -->
</div>
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/partials/aside/index.blade.php ENDPATH**/ ?>