<!DOCTYPE html>
<!--[if IE 8]>
<html lang="<?php echo e(GetLanguage()); ?>" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]>
<html lang="<?php echo e(GetLanguage()); ?>" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(GetLanguage()); ?>" dir="<?php echo e(GetDirection()); ?>">

	<head>
		<meta charset="utf-8" />
		<title><?php echo e($title); ?> || </title>
		<meta name="description" content="Latest updates and statistic charts">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<meta name="app-url" content="<?php echo e(aurl('/')); ?>">

		<!--begin::Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet">
		<!--end::Fonts -->

		<!--begin::Page Vendors Styles(used by this page) -->
		<?php echo $__env->yieldContent('styles'); ?>
		<!--end::Page Vendors Styles -->

		<!--begin::Global Theme Styles(used by all pages) -->
		<link href="<?php echo e(asset("backend_additional/dist/assets/plugins/global/plugins.bundle".addRtl().".css")); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo e(asset("backend_additional/dist/assets/css/style.bundle".addRtl().".css")); ?>" rel="stylesheet" type="text/css" />

		<!--end::Global Theme Styles -->

		<!--begin::Layout Skins(used by all pages) -->

		<!--end::Layout Skins -->

		<style media="screen">
			.required::after { content:"*"; color: #f4516c; }
			[v-cloak] { display:none; }
			.todoFormContainer {
				background-color: #f9f9fc;
				padding: 10px;
				box-shadow: 2px 2px 4px #f9f9fc;
				border-radius: 5px;
			}
		</style>

		
		<?php if(GetLanguage() == 'ar'): ?>
			<style>
				.lg-outer {
					direction: ltr;
				}
				.vue-form-wizard.md .wizard-navigation .wizard-progress-with-circle {
					transform: rotate(180deg);
				}
			</style>
		<?php endif; ?>
        <style>
            .btn-brand:hover{
                color: white !important;
            }
        </style>
		<link rel="shortcut icon" href="<?php echo ShowImageFromStorage(null, 'WebsiteSetting-collection', 'avatar'); ?>"/>
        @livewireStyles
	</head>

	<!-- end::Head -->

	<!-- begin::Body -->
	<body class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-menu kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-aside--enabled kt-aside--left kt-aside--fixed kt-page--loading">

        

		<!-- begin:: Page -->

		<!-- begin:: Header Mobile -->
		<div id="kt_header_mobile" class="kt-header-mobile  kt-header-mobile--fixed ">
			<div class="kt-header-mobile__logo">
				<a href="<?php echo e(url('/')); ?>">
					<img height="50px" src="<?php echo ShowImageFromStorage(null, 'WebsiteSetting-collection', 'avatar'); ?>" alt="Logo">
				</a>
			</div>
			<div class="kt-header-mobile__toolbar">
				<button class="kt-header-mobile__toolbar-toggler kt-header-mobile__toolbar-toggler--left" id="kt_aside_mobile_toggler"><span></span></button>
				<button class="kt-header-mobile__toolbar-toggler" id="kt_header_mobile_toggler"><span></span></button>
				<button class="kt-header-mobile__toolbar-topbar-toggler" id="kt_header_mobile_topbar_toggler"><i class="flaticon-more-1"></i></button>
			</div>
		</div>
		<!-- end:: Header Mobile -->

		<div class="kt-grid kt-grid--hor kt-grid--root">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
				<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-wrapper" id="kt_wrapper">

					<!-- begin:: Header -->
					<div id="kt_header" class="kt-header  kt-header--fixed " data-ktheader-minimize="on">
						<div class="kt-container  kt-container--fluid ">
							<!-- begin: Header Menu -->
							<?php echo $__env->make('backend.layout.partials.header-menu.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<!-- end: Header Menu -->
							<!-- begin:: Brand -->
							<div class="kt-header__brand   kt-grid__item" id="kt_header_brand">
								<a href="<?php echo e(url('admin')); ?>" class="kt-header__brand-logo">
									<img height="50px" src="<?php echo ShowImageFromStorage(null, 'WebsiteSetting-collection',''); ?>" alt="Logo">
								</a>
							</div>
							<!-- end:: Brand -->

							<!-- begin:: Header Topbar -->
							<?php echo $__env->make('backend.layout.partials.header-topbar.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<!-- end:: Header Topbar -->
						</div>
					</div>
					<!-- end:: Header -->

					<!-- begin:: Aside -->
					<?php echo $__env->make('backend.layout.partials.aside.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- end:: Aside -->

					<div class="kt-body kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor kt-grid--stretch" id="kt_body">
						<div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
							<!-- begin:: Subheader -->
							<?php echo $__env->yieldContent('sub_header'); ?>
							<!-- end:: Subheader -->

							<!-- begin:: Content -->
							<div class="kt-container  kt-grid__item kt-grid__item--fluid">
								<?php echo $__env->yieldContent("content"); ?>
							</div>
							<!-- end:: Content -->
						</div>
					</div>

					<!-- begin:: Footer -->
					<?php echo $__env->make('backend.layout.partials.footer.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- end:: Footer -->
				</div>
			</div>
		</div>
		<!-- end:: Page -->

		<!-- begin::Quick Panel -->
		
		<!-- end::Quick Panel -->

		<!-- begin::Scrolltop -->
		<div id="kt_scrolltop" class="kt-scrolltop">
			<i class="fa fa-arrow-up"></i>
		</div>
		<!-- end::Scrolltop -->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#591df1",
						"light": "#ffffff",
						"dark": "#282a3c",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": ["#c5cbe3", "#a1a8c3", "#3d4465", "#3e4466"],
						"shape": ["#f0f3ff", "#d9dffa", "#afb4d4", "#646c9a"]
					}
				}
			};

			window.datePickerTranslations = {
				weekdays: [
					'<?php echo e(__("main.mon")); ?>', '<?php echo e(__("main.tue")); ?>', '<?php echo e(__("main.wed")); ?>', '<?php echo e(__("main.thu")); ?>', '<?php echo e(__("main.fri")); ?>', '<?php echo e(__("main.sat")); ?>', '<?php echo e(__("main.sun")); ?>'
				],
				nextMonthCaption: '<?php echo e(__("main.next_month")); ?>',
				prevMonthCaption: '<?php echo e(__("main.prev_month")); ?>',
				setTimeCaption: '<?php echo e(__("main.set_time")); ?>',
				monthes: [
	                '<?php echo e(__("main.January")); ?>', '<?php echo e(__("main.February")); ?>', '<?php echo e(__("main.March")); ?>', '<?php echo e(__("main.April")); ?>',
	                '<?php echo e(__("main.May")); ?>', '<?php echo e(__("main.June")); ?>', '<?php echo e(__("main.July")); ?>', '<?php echo e(__("main.August")); ?>',
	                '<?php echo e(__("main.September")); ?>', '<?php echo e(__("main.October")); ?>', '<?php echo e(__("main.November")); ?>', '<?php echo e(__("main.December")); ?>'
	            ],
				next: '<?php echo e(__("main.next")); ?>',
				prev: '<?php echo e(__("main.prev")); ?>',
			};

			window.trans = <?php
	        	// copy all translations from /resources/lang/CURRENT_LOCALE/* to global JS variable
	        	$lang_files = File::files(resource_path() . '/lang/' . App::getLocale());
	        	$trans = [];
		        foreach ($lang_files as $f) {
		            $filename = pathinfo($f)['filename'];
		            $trans[$filename] = trans($filename);
		        }
	        	echo json_encode($trans);
	        ?>

			window.currentUserId = '<?php echo e(auth()->id()); ?>';

			window.currentDates = {
				year: '<?php echo e(date("Y")); ?>',
				month: '<?php echo e(date("m")); ?>',
				day: '<?php echo e(date("d")); ?>',
				hour: '<?php echo e(date("H")); ?>',
				minute: '<?php echo e(date("i")); ?>',
				second: '<?php echo e(date("s")); ?>',
				date: '<?php echo e(date("Y-m-d")); ?>',
				dateTime: '<?php echo e(date("Y-m-d H:i:s")); ?>',
				time: '<?php echo e(date("H:i")); ?>',
			};
		</script>


		
		<!-- end::Global Config -->

		<!--begin::Global Theme Bundle(used by all pages) -->
        <script src="https://unpkg.com/vue-multiselect@2.1.0"></script>
        <script src="<?php echo e(asset('backend/dist/assets/plugins/global/plugins.bundle.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('backend/dist/assets/js/scripts.bundle.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('backend/shared/js/vue.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('backend/shared/js/helpers.js')); ?>" type="text/javascript"></script>

        <script src="<?php echo e(asset("backend/dist/assets/plugins/custom/datatables/datatables.bundle.js")); ?>" type="text/javascript"></script>
        <script src="https://unpkg.com/vue-form-wizard/dist/vue-form-wizard.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/intro.js/2.9.3/intro.min.js"></script>
        <script src="<?php echo e(asset("backend/dist/assets/js/pages/custom/wizard/wizard-4.js")); ?>" type="text/javascript"></script>


        <?php echo $__env->make('backend.layout.globals.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!--end::Global Theme Bundle -->

		<?php echo $__env->make('backend.layout.globals.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
            $( document ).ready(function() {
                $('.kt-header__topbar-icon').on('click',function(e){
                    e.preventDefault();
                    setTimeout(function() {
                        $('#kt-quick-panel-search').focus();
                        $('#kt-quick-panel-search_lead').focus();
                    }, 100);
                })

            });
        </script>

		<!--begin::Page Vendors(used by this page) -->
		<?php echo $__env->yieldContent('js_vendors'); ?>
		<!--end::Page Vendors -->

		<!--begin::Page Scripts(used by this page) -->
		<?php echo $__env->yieldContent('js_scripts'); ?>
		<!--end::Page Scripts -->
        @livewireScripts

	</body>

	<!-- end::Body -->
</html>
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/app.blade.php ENDPATH**/ ?>