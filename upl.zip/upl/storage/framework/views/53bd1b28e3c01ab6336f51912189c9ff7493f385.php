<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('backend/dist/assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub_header'); ?>
    <?php $__env->startComponent('backend.layout.components.sub-header'); ?>
        <?php $__env->slot('title'); ?>
            <?php echo e($title); ?>

        <?php $__env->endSlot(); ?>

        <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
        <span class="kt-subheader__breadcrumbs-separator"></span>
        <a href="<?php echo e(route('admin.rethink_obesity.index')); ?>" class="kt-subheader__breadcrumbs-link">
            <?php echo e(__('main.rethink_obesity')); ?>

        </a>
        <span class="kt-subheader__breadcrumbs-separator"></span>
        <a href="#" class="kt-subheader__breadcrumbs-link">
            <?php echo e(__('main.show-all')); ?> <?php echo e(__('main.rethink_obesity')); ?>

        </a>
    <?php if (isset($__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80)): ?>
<?php $component = $__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80; ?>
<?php unset($__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="kt-portlet kt-portlet--last kt-portlet--head-lg kt-portlet--responsive-mobile">
                <div class="kt-portlet__head kt-portlet__head--lg">
                    <div class="kt-portlet__head-label">
                        <span class="kt-portlet__head-icon">
                            <i class="kt-font-brand flaticon2-line-chart"></i>
                        </span>
                        <h3 class="kt-portlet__head-title">
                            <?php echo e($title); ?>

                        </h3>
                    </div>
                    <div class="kt-portlet__head-toolbar">
                        <div class="kt-portlet__head-wrapper">
                            <div class="dropdown dropdown-inline">
                                <a href="<?php echo e(route('admin.rethink_obesity.create')); ?>" class="btn btn-brand btn-icon-sm">
                                    <i class="flaticon2-plus"></i> <?php echo e(__('main.add_new')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="kt-portlet__body">
                    <!--begin: Datatable -->
                <?php echo $dataTable->table(['class' => 'table table-striped table-bordered table-hover table-checkable'], true); ?>

                <!--end: Datatable -->
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_scripts'); ?>
    <?php echo $dataTable->scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/rethink_obesity/index.blade.php ENDPATH**/ ?>