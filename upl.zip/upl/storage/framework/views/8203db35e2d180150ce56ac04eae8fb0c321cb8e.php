<button class="kt-header-menu-wrapper-close" id="kt_header_menu_mobile_close_btn">
    <i class="la la-close"></i>
</button>

<div class="kt-header-menu-wrapper kt-grid__item kt-grid__item--fluid" id="kt_header_menu_wrapper">
    <button class="kt-aside-toggler kt-aside-toggler--left" id="kt_aside_toggler">
        <span></span>
    </button>
    <div id="kt_header_menu" class="kt-header-menu kt-header-menu-mobile ">
        <ul class="kt-menu__nav">
            <li class="kt-menu__item  kt-menu__item--submenu kt-menu__item--rel" data-ktmenu-submenu-toggle="click"
                aria-haspopup="true">
            <li class="kt-menu__item kt-menu__item--submenu kt-menu__item--rel <?php echo e(is_active('admin')); ?>"
                data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                <a href="<?php echo e(aurl('/')); ?>" class="kt-menu__link">
                    <span class="kt-menu__link-text"><?php echo e(__('main.dashboard')); ?></span>
                    <i class="kt-menu__ver-arrow la la-angle-right"></i>
                </a>
            </li>

            <li class="kt-menu__item  kt-menu__item--submenu kt-menu__item--rel <?php echo e(is_active('admin/users',true)); ?>"
                data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="kt-menu__link">
                    <span class="kt-menu__link-text"><?php echo e(__('main.users')); ?></span>
                    <i class="kt-menu__ver-arrow la la-angle-right"></i>
                </a>
            </li>
            <li class="kt-menu__item  kt-menu__item--submenu kt-menu__item--rel <?php echo e(is_active('admin/youtube_video')); ?>"
                data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                <a href="<?php echo e(route('admin.youtube_video.index')); ?>" class="kt-menu__link">
                    <span class="kt-menu__link-text"><?php echo e(__('main.youtube_video_hyper_link')); ?></span>
                    <i class="kt-menu__ver-arrow la la-angle-right"></i>
                </a>
            </li>
            <li class="kt-menu__item  kt-menu__item--submenu kt-menu__item--rel <?php echo e(is_active('admin/rethink_obesity')); ?>"
                data-ktmenu-submenu-toggle="click" aria-haspopup="true">
                <a href="<?php echo e(route('admin.rethink_obesity.index')); ?>" class="kt-menu__link">
                    <span class="kt-menu__link-text"><?php echo e(__('main.rethink_obesity')); ?></span>
                    <i class="kt-menu__ver-arrow la la-angle-right"></i>
                </a>
            </li>

        </ul>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/partials/header-menu/index.blade.php ENDPATH**/ ?>