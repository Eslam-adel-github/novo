<?php $__env->startSection('sub_header'); ?>
    <?php $__env->startComponent('backend.layout.components.sub-header'); ?>

        <?php $__env->slot('title'); ?>
            <?php echo e($title); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('toolbar'); ?>
            <li class="kt-nav__item">
                <a href="<?php echo e(route('admin.youtube_video.edit', [$show->id])); ?>" class="kt-nav__link">
                    <i class="kt-nav__link-icon flaticon-edit"></i>
                    <span class="kt-nav__link-text"><?php echo e(__('main.edit')); ?> <?php echo e(__('main.youtube_video_hyper_link')); ?></span>
                </a>
            </li>
            <li class="kt-nav__item">
                <a href="<?php echo e(route('admin.youtube_video.index')); ?>" class="kt-nav__link">
                    <i class="kt-nav__link-icon flaticon-list-2"></i>
                    <span class="kt-nav__link-text"><?php echo e(__('main.show-all')); ?> <?php echo e(__('main.youtube_video_hyper_link')); ?></span>
                </a>
            </li>
        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80)): ?>
<?php $component = $__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80; ?>
<?php unset($__componentOriginalc7828e961428048f1ee309c9e77fb279a2db4f80); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="kt-portlet kt-portlet--mobile">
                <div class="kt-portlet__head">
                    <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                            <?php echo e($title); ?>

                        </h3>
                    </div>
                </div>
                <div class="kt-portlet__body">
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(__('main.name')); ?>: </strong>
                            <?php echo e(VarByLang(getData(collect($show),"name"))); ?>

                            <hr>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e(__('main.hyper_link')); ?>: </strong>
                            <a target="_blank" href="<?php echo e($show->hyper_link); ?>">Hyper Link</a>
                            <hr>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(__('main.created_at')); ?>: </strong>
                            <?php echo e($show->created_at); ?>

                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/youtube_video/show.blade.php ENDPATH**/ ?>