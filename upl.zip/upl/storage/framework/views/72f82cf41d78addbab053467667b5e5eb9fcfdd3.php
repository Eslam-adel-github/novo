<!--begin: Notifications -->

<div class="kt-header__topbar-item dropdown">
	<div class="kt-header__topbar-wrapper" data-toggle="dropdown" data-offset="10px,0px">
		<span class="kt-header__topbar-icon" @click="getNotifications()"><i class="flaticon2-bell-alarm-symbol"></i></span>
		<span v-if="count_unread" class="kt-badge kt-badge--danger"></span>
	</div>
    
</div>


<!--end: Notifications -->
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/partials/header-topbar/partials/_notifications.blade.php ENDPATH**/ ?>