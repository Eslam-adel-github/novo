<div class="kt-footer kt-grid__item" id="kt_footer">
    <div class="kt-container ">
        <div class="kt-footer__wrapper">
            <div class="kt-footer__copyright">
                <?php echo e(date('Y')); ?>&nbsp;&copy;&nbsp; <a href="https://ibraintechs.com" target="_blank" class="kt-link"> iBrain Technologies </a>  &nbsp;<?php echo e(config('adminMenu.footer.version')); ?>

            </div>
            <div class="kt-footer__menu">

                <?php $__currentLoopData = config('adminMenu.footer.links'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a rel="noreferrer" href="<?php echo e($link['link']); ?>" target="<?php echo e($link['target'] ? '_blank' : $link['target']); ?>" class="<?php echo e($link['class']); ?>"><?php echo e(__('main.'.$link['title'])); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/partials/footer/index.blade.php ENDPATH**/ ?>