<div class="kt-header__topbar-item kt-header__topbar-item--user">
    <div class="kt-header__topbar-wrapper" data-toggle="dropdown" data-offset="10px,0px">
        <span class="kt-header__topbar-username kt-visible-desktop"><?php echo e(auth()->user()->name); ?></span>
        <img alt="Pic" src="<?php echo ShowImageFromStorage(null, 'WebsiteSetting-collection', 'avatar'); ?>" />

        <!--use below badge element instead the user avatar to display username's first letter(remove kt-hidden class to display it) -->
        <span class="kt-badge kt-badge--username kt-badge--unified-success kt-badge--lg kt-badge--rounded kt-badge--bold kt-hidden">S</span>
    </div>
    <div class="dropdown-menu dropdown-menu-fit dropdown-menu-right dropdown-menu-anim dropdown-menu-xl">

        <!--begin: Head -->
        <div class="kt-user-card kt-user-card--skin-light kt-notification-item-padding-x">
            <div class="kt-user-card__avatar">
                <!--use below badge element instead the user avatar to display username's first letter(remove kt-hidden class to display it) -->
                <span class="kt-badge kt-badge--username kt-badge--unified-info kt-badge--md kt-badge--rounded kt-badge--light"><?php echo e(getFirstCharacters(auth()->user()->name)); ?></span>
            </div>
            <div class="kt-user-card__name">
                <?php echo e(auth()->user()->name); ?>

            </div>
            <div class="kt-user-card__badge">
                <span class="btn btn-label-info btn-sm btn-bold btn-font-md">3</span>
            </div>
        </div>

        <!--end: Head -->

        <!--begin: Navigation -->
        <div class="kt-notification">

            <div class="kt-notification__custom kt-space-between">
                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" target="_blank" class="btn btn-label btn-label-brand btn-sm btn-bold">Sign Out</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
        <!--end: Navigation -->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\novo_nor_disk\resources\views/backend/layout/partials/header-topbar/partials/_user_bar.blade.php ENDPATH**/ ?>