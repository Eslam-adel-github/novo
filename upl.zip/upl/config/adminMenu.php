<?php

return[
  'footer' => [

     'links' => [
         /*
          [
              'title'  => 'support',
              'link'   => 'https://support.ibraintechs.com/',
              'target' => '_blank',
              'class'  => 'kt-link'
          ],
          [
              'title'  => 'documentation',
              'link'    => 'https://support.ibraintechs.com/',
              'target' => '_blank',
              'class'  => 'kt-link'
          ],
          [
              'title'  => 'contact_us',
              'link'    => 'https://support.ibraintechs.com/',
              'target' => '_blank',
              'class'  => 'kt-link'
          ]
         */
        ],

     'version' => 'V 1.0.0'
  ]
];
