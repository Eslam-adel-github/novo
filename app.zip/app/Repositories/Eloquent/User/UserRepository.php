<?php

namespace App\Repositories\Eloquent\User;

interface UserRepository
{
    // code...
}
