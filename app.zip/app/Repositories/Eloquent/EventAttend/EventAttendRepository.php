<?php


namespace App\Repositories\Eloquent\EventAttend;


interface EventAttendRepository
{

}
