<?php


namespace App\Repositories\Eloquent\HCP;


interface HCPRepository
{

}
