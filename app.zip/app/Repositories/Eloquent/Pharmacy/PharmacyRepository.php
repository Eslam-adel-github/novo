<?php


namespace App\Repositories\Eloquent\Pharmacy;


interface PharmacyRepository
{

}
