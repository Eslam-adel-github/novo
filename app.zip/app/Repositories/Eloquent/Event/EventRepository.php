<?php


namespace App\Repositories\Eloquent\Event;


interface EventRepository
{

}
