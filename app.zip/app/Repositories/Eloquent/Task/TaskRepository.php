<?php


namespace App\Repositories\Eloquent\Task;


interface TaskRepository
{

}
