<?php


namespace App\Repositories\Eloquent\Library;


interface LibraryRepository
{

}
