<?php


namespace App\Repositories\Eloquent\CategeoryVideo;


interface CategoryVideoRepository
{

}
