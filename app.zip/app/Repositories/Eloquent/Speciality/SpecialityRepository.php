<?php


namespace App\Repositories\Eloquent\Speciality;


interface SpecialityRepository
{

}
