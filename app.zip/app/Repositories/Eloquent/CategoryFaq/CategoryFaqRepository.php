<?php


namespace App\Repositories\Eloquent\CategoryFaq;


interface CategoryFaqRepository
{

}
