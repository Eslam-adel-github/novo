<?php


namespace App\Repositories\Eloquent\TempleteEvent;


interface TempleteEventRepository
{

}
