<?php


namespace App\Repositories\Eloquent\YoutubeVideo;


interface YoutubeVideoRepository
{

}
