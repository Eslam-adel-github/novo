<?php

namespace App\Repositories\Eloquent\WebSetings;

interface WebsiteSettingRepository
{
}
