<?php


namespace App\Repositories\Eloquent\RethinkObesity;


interface RethinkObesityRepository
{

}
