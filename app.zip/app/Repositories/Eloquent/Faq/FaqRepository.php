<?php


namespace App\Repositories\Eloquent\Faq;


interface FaqRepository
{

}
