<?php


namespace App\Repositories\Eloquent\EventType;


interface EventTypeRepository
{

}
