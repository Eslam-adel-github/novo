<?php


namespace App\Repositories\Eloquent\CategoryLibrary;


interface CategoryLibraryRepository
{

}
