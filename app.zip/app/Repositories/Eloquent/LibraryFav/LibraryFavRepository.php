<?php


namespace App\Repositories\Eloquent\LibraryFav;


interface LibraryFavRepository
{

}
