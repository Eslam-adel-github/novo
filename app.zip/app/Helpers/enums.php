<?php

/*
Not needed as we can rely on roles
function user_types()
{
    return [
        'user',
        'vendor',
        'admin',
    ];
}
*/
function getParticipations(){
    return [
        "doctor",
        "public"
    ];
}
